<?php

class Nchannel_Communicator_IndexController extends Mage_Adminhtml_Controller_Action{

	public function helloAction(){
		echo "Hello World";
	}
}

?>