<?php
class Nchannel_Communicator_Model_Api extends Mage_Catalog_Model_Api_Resource 
{
	function linkConfigurable()
	{
		return 'xxx';
	}
}