<?php
$installer = $this;
$installer->startSetup();

$installer->setConfigData('explodedmenu/columns/categories_per_column', 5);	
$installer->endSetup(); 