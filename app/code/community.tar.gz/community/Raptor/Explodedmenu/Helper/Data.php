<?php
class Raptor_Explodedmenu_Helper_Data extends Mage_Core_Helper_Abstract
{
}

