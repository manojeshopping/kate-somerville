<?php

/**
 * Conflictchecker Helper
 *
 * @category  Bronto
 * @package   Bronto_Verify
 * @author    Adam Daniels <adam.daniels@atlanticbt.com>
 * @copyright 2013 Adam Daniels
 */
class Bronto_Verify_Helper_Conflictchecker
    extends Bronto_Verify_Helper_Data
{

}