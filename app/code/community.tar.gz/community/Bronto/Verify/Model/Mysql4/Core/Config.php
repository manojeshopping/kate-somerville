<?php

/**
 * Mysql config
 *
 * @category  Bronto
 * @package   Bronto_Verify
 * @author    Adam Daniels <adam.daniels@atlanticbt.com>
 * @copyright 2013 Adam Daniels
 */
class Bronto_Verify_Model_Mysql4_Core_Config
    extends Bronto_Verify_Model_Resource_Core_Config
{
}
