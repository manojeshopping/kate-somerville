<?php

$installer = $this;

$installer->startSetup();
$installer->updateTables('1.2.0');
$installer->endSetup();
