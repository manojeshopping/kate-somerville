<?php

/**
 * @package   Bronto\Reminder
 * @copyright 2011-2013 Bronto Software, Inc.
 */
class Bronto_Reminder_Model_System_Config_Backend_Allowsend extends Mage_Core_Model_Config_Data
{

    protected $_eventPrefix = 'bronto_reminder_allowsend';

}
