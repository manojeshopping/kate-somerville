<?php

$installer = $this;

$installer->startSetup();
$installer->updateTables('1.4.17');
$installer->endSetup();
