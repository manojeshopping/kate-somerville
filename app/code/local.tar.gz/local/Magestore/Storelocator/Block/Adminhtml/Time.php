<?php
class Magestore_Storelocator_Block_Adminhtml_Time extends Mage_Core_Block_Template
{
 
}
